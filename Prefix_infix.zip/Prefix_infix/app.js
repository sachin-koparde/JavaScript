const obj1 = document.querySelector("#btn");
var result1;
var result2;
obj1.addEventListener("click", function() {

    var tm1 = infixToPrefix();
    var tm2 = infixToPostfix();
    if(tm1>tm2){
        alert("Converting from Infix to Prefix took more time than converting to Postfix");
    } else{
        alert("Converting from Infix to Postfix took more time than converting Prefix");
    }
});


function infixToPrefix() {
    var t0 = performance.now()
    var input = document.getElementById("input").value;
    // var input = "1 + 2 + 3";
    var x = input.split(''); // splits each character and stores it in an array
    var operands = [];
    var numbers = [];
    var symbols = ['+', '-', '/', '*', '%'];

    for (var i = 0; i < x.length; i++) {
    if(symbols.includes(x[i])) {
    operands.push(x[i]);
    } else {
    numbers.push(x[i]);
    }
}
var final = operands.join(' ') +' ' +numbers.join(' ');
var t1 = performance.now()

alert("Prefix: "+final);
alert("The time taken to convert Infix to Prfix " + (t1 - t0) + " milliseconds.");
return t1-t0;
}

function infixToPostfix(){
    var time1 = performance.now()
    var infix = document.getElementById("input").value;

    infix = tokenize(infix);
    
    const presedences = ["-", "+", "*", "/"];

    var opsStack = [],
        postfix = [];

    for(let token of infix){
        // Step 1
        if("number" === typeof token){
            postfix.push(token); continue;
        }
        let topOfStack = opsStack[opsStack.length - 1];
        // Step 2
        if(!opsStack.length || topOfStack == "("){
            opsStack.push(token); continue;
        }
        // Step 3
        if(token == "("){
            opsStack.push(token); continue;
        }
        // Step 4
        if(token == ")"){
            while(opsStack.length){
                let op = opsStack.pop();
                if(op == "(")	break;
                postfix.push(op);
            }
            continue;
        }
        // Step 5
        let prevPresedence = presedences.indexOf(topOfStack),
            currPresedence = presedences.indexOf(token);
        while(currPresedence < prevPresedence){
            let op = opsStack.pop();
            postfix.push(op);
            prevPresedence = presedences.indexOf(opsStack[opsStack.length - 1]);
        }
        opsStack.push(token);
    }
    // Step 6
    while(opsStack.length){
        let op = opsStack.pop();
        if(op == "(")	break;
        postfix.push(op);
    }
    var n = "";
    for(var i=0; i <= postfix.length-1; i++){
    n = n + postfix[i].toString();
    }

    var time2 = performance.now()
    alert("Postfix: "+n);
    alert("The time taken to convert Infix to Postfix " + (time2 - time1) + " milliseconds.");

    return time1-time2;
}

function tokenize(exp){
return exp
    .replace(/\s/g, "")
    .split("")
    .map((token, i) => /^\d$/.test(token) ? +token : token);
}

// function prefixAndPostfix() {

// var foobar = document.getElementById("option").value;

// if(foobar === "prefix"){
// myFunction();
// }
// else if(foobar === "postfix") {
// infixToPostfix();
// }



//}


